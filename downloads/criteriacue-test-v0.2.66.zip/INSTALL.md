# CriteriaCue 测试版安装与更新

统一下载入口见 [下载与安装入口](downloads.md)：[Chrome 商店](https://chromewebstore.google.com/detail/gnbphmdpnhlbakiaegfgmppnajemboij)、[Edge 商店](https://microsoftedge.microsoft.com/addons/detail/aecndleilbgafmfclfjiilafoaaekfoc)、[主页 ZIP 下载区](https://criteriacue.minus.team/#download)。商店与手动测试包版本可能不同；下文仅针对手动安装的测试包。

分发文件：`criteriacue-test-v版本号.zip`。请选择文件名包含 `-test-` 的测试包，不使用普通商店提交包解压分发。

固定扩展 ID：`iolkljnhkdblmpoohjfkkhmkalfaknlf`。

## 首次安装

1. 将 ZIP 完整解压到一个长期保留的文件夹。不要在 ZIP 内直接加载，也不要编辑 `manifest.json`。
2. Chrome 打开 `chrome://extensions`；Edge 打开 `edge://extensions`，开启“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择直接包含 `manifest.json` 的文件夹。
4. 确认名称包含 `CriteriaCue` 和 `(Test)`，扩展 ID 与上方一致。安装路径、电脑和操作系统不参与本测试包的 ID 生成。
5. 点击扩展图标，按引导选择语言、授权所用招聘网站、通过邮箱验证码注册或登录，再设置岗位。每位用户使用自己的邮箱，无需申请逐人放行。

如果曾安装旧版无固定 ID 的解压包，新版会被浏览器识别为另一扩展。先保留或复制旧岗位 JD 和最终要求，再关闭旧版以避免同时审阅，在新版重新登录、授权和设置岗位。旧版登录及本地岗位不会自动迁移；新 ID 稳定以后，按下面方式更新即可保留本地数据。

## 后续更新

1. 保留当前安装文件夹，不卸载扩展。
2. 使用新的 `criteriacue-test-v版本.zip` 完整替换该文件夹内的文件，包括 `manifest.json`。
3. 在扩展管理页点击该测试扩展的“重新加载”。ID 保持不变，本地岗位和偏好仍属于同一扩展；过期登录或新增权限按页面提示处理。

解压测试版不经商店自动更新，需要手动替换文件并重新加载。固定 ID 解决的是扩展来源稳定性，不代表可绕过验证码、登录或平台用量保护。

## 维护者构建

在项目根目录运行：

```sh
npm run build:test
```

生成 `release/criteriacue-test/` 和 `release/criteriacue-test-v版本.zip`，不会覆盖本机正在使用的 `dist`。脚本读取 `scripts/unpacked-test-identity.json` 中固定公钥；不要每次生成新的身份文件。

`npm run build` 仍是普通构建和商店提交包，不注入测试公钥。测试身份使用公开的 manifest `key`，没有平台 Key、密码或私钥；它不是 API 凭据。后台只放行对应的精确 Origin，仍需邮箱验证并执行原有用量保护。

依据：[Chrome 官方 manifest key 文档](https://developer.chrome.com/docs/extensions/reference/manifest/key)。
